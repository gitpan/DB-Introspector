package DB::Introspector::Oracle::TypeMapper;

use strict;
use base qw ( DB::Introspector::SQLGen::TypeMapper );






1;
